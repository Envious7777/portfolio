# s-mbf
Simple Multi BruteForce by KANG-NEWBIE<br>
# Update:
- v.2.1<br>
Add Target comments v2 (module no 12)<br>
Add Auto UNTAG<br>
Add Download all image from messages<br>
Bug fixed
- v.2.0<br>
Add Auto deleted all messages<br>
Optimize module Abrute,Mreport, and Tkomen (2,18,and 12)
- v.1.9<br>
FIX THE FUCKING BUGS!!!
- v.1.8<br>
Add Auto multi bruteforce<br>
Add Auto reset password<br>
Optimize Update module and Dump email module
- v.1.7<br>
Optimize Friend requests<br>
Optimize Delete Friends<br>
Add Leave all Groups
- v.1.6<br>
Optimize Dump id group<br>
removed Bruteforce Email<br>
Add Deleted post<br>
Add Checker accounts
- v.1.5<br>
Add Check apps and optimize for windows7
- v.1.4<br>
Add Dump id with search name
- v.1.3<br>
Optimize module number 4,11,and 14
- v.1.2<br>
Optimize module number 14
- v.1.1<br>
Optimize module number 1,2,3,5 and 6
- v.1.0<br>
Add facebook dump mail and simple multi bruteforce EMAIL

# installation
<b>installation for windows:</b><br>
Download <a href='https://www.python.org'>python3</a><br>
Download <a href='https://git-scm.com/downloads'>git</a><br>
Now type this command in your cmd:
```
git clone https://github.com/KANG-NEWBIE/s-mbf
cd s-mbf
python -m pip install -r req.txt
python embf.py
```
<b>installation for termux or linux:</b>
```
apt update && apt upgrade
apt-get install python
apt-get install git
git clone https://github.com/KANG-NEWBIE/s-mbf
cd s-mbf
python -m pip install -r req.txt
python embf.py
```
<h1>Note:</h1>
Check my other repository <a href="https://github.com/KANG-NEWBIE?tab=repositories">here</a>
