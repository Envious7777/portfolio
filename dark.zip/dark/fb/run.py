# Tusbolled by deray

import interpreter
interpreter.menu()
